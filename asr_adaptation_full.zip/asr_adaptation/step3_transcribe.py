"""
Шаг 3 — Автоматически разметить аудиофайлы через Whisper и создать train/val CSV.

Берёт папку с аудио (структура как в бейзлайне — папки по speaker_id),
прогоняет каждый файл через Whisper и сохраняет транскрипции в CSV.

Запуск:
    python step3_transcribe.py \\
        --audio_dir  ./data/train \\
        --out_dir    ./data \\
        --language   ru \\
        --model_size medium \\
        --val_ratio  0.1

Результат:
    ./data/train_asr.csv  — обучающая выборка
    ./data/val_asr.csv    — валидационная выборка

Размеры моделей Whisper (точность vs скорость):
    tiny    — быстро, WER ~30–40%  (для теста пайплайна)
    base    — быстро, WER ~20–30%
    small   — баланс, WER ~15–25%
    medium  — медленно, WER ~10–20%  ← рекомендуется
    large   — очень медленно, WER ~7–15%

Примечание: транскрипции Whisper — это псевдо-разметка.
Для финального качества лучше использовать реальные транскрипции,
но для старта это хорошая база.
"""

import argparse
import os
import random
from pathlib import Path

import pandas as pd
from tqdm import tqdm


def find_audio_files(audio_dir: Path) -> list:
    """
    Ищет все .flac и .wav файлы.
    Поддерживает две структуры:
        flat:   audio_dir/000001.flac
        nested: audio_dir/speaker_id/000001.flac  (структура бейзлайна)
    """
    exts = {".flac", ".wav", ".mp3"}
    files = []
    for p in sorted(audio_dir.rglob("*")):
        if p.is_file() and p.suffix.lower() in exts:
            files.append(p)
    return files


def transcribe_batch(files: list, model, language: str, base_dir: Path) -> list:
    """Прогоняет список файлов через Whisper, возвращает список словарей."""
    results = []
    for path in tqdm(files, desc="Транскрибируем", unit="файл"):
        try:
            result = model.transcribe(
                str(path),
                language=language,
                fp16=False,         # fp16 может давать артефакты на CPU
                verbose=False,
            )
            text = result["text"].strip()
            # Относительный путь от base_dir
            rel_path = path.relative_to(base_dir) if path.is_relative_to(base_dir) else path
            results.append({
                "filepath": str(rel_path),
                "transcript": text,
            })
        except Exception as e:
            print(f"\n[WARN] Ошибка при обработке {path.name}: {e}")
            continue
    return results


def split_train_val(records: list, val_ratio: float, seed: int = 42):
    """Делит записи на train/val, сохраняя баланс по дикторам если возможно."""
    random.seed(seed)
    random.shuffle(records)
    split = int(len(records) * (1 - val_ratio))
    return records[:split], records[split:]


def main():
    parser = argparse.ArgumentParser(description="Авторазметка аудио через Whisper")
    parser.add_argument("--audio_dir",  required=True, help="Папка с аудиофайлами")
    parser.add_argument("--out_dir",    default="./data", help="Куда сохранить CSV")
    parser.add_argument("--language",   default="ru", help="Язык: ru, en, ...")
    parser.add_argument("--model_size", default="medium",
                        choices=["tiny", "base", "small", "medium", "large"],
                        help="Размер модели Whisper")
    parser.add_argument("--val_ratio",  type=float, default=0.1,
                        help="Доля валидации (0.0–1.0)")
    parser.add_argument("--max_files",  type=int, default=None,
                        help="Максимум файлов (для быстрого теста)")
    parser.add_argument("--base_dir",   default=None,
                        help="Базовая директория для относительных путей (по умолчанию = audio_dir)")
    args = parser.parse_args()

    audio_dir = Path(args.audio_dir)
    out_dir   = Path(args.out_dir)
    base_dir  = Path(args.base_dir) if args.base_dir else audio_dir.parent
    out_dir.mkdir(parents=True, exist_ok=True)

    # Находим файлы
    print(f"[INFO] Ищем аудиофайлы в {audio_dir} ...")
    files = find_audio_files(audio_dir)
    print(f"[INFO] Найдено: {len(files)} файлов")

    if not files:
        print("[ERR] Аудиофайлы не найдены. Проверь --audio_dir")
        return

    if args.max_files:
        files = files[:args.max_files]
        print(f"[INFO] Ограничение: {len(files)} файлов")

    # Загружаем Whisper
    print(f"\n[INFO] Загружаем Whisper '{args.model_size}'...")
    import whisper
    model = whisper.load_model(args.model_size)
    print(f"[INFO] Модель загружена. Язык: {args.language}")
    print(f"[INFO] Начинаем транскрибирование...\n")

    # Транскрибируем
    records = transcribe_batch(files, model, args.language, base_dir)
    print(f"\n[INFO] Транскрибировано: {len(records)} файлов")

    if not records:
        print("[ERR] Нет результатов")
        return

    # Разбиваем на train/val
    train_records, val_records = split_train_val(records, args.val_ratio)

    # Сохраняем CSV
    train_path = out_dir / "train_asr.csv"
    val_path   = out_dir / "val_asr.csv"

    pd.DataFrame(train_records).to_csv(train_path, index=False, encoding="utf-8")
    pd.DataFrame(val_records).to_csv(val_path,   index=False, encoding="utf-8")

    print(f"\n[ГОТОВО]")
    print(f"  train_asr.csv : {len(train_records)} записей → {train_path}")
    print(f"  val_asr.csv   : {len(val_records)} записей → {val_path}")

    # Показываем примеры
    print("\n[Примеры транскрипций]")
    for r in records[:5]:
        print(f"  {r['filepath']}")
        print(f"  → \"{r['transcript']}\"")
        print()

    print("[Следующий шаг]")
    print("  python train_asr.py --config configs/asr.json")


if __name__ == "__main__":
    main()
