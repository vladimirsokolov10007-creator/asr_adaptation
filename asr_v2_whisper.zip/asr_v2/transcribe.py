"""
Инференс: транскрибирование аудиофайлов обученной моделью.

Поддерживает:
  - Одиночный файл
  - Директорию (рекурсивно)
  - Батчевую обработку для скорости
  - Вывод в CSV или stdout

Запуск:
    # Один файл:
    python transcribe.py --model ./experiments/whisper-small-ru/final --audio audio.wav

    # Директория → CSV:
    python transcribe.py --model ./experiments/whisper-small-ru/final \
        --audio_dir ./data/test \
        --output results.csv \
        --language russian

    # Оценка WER на CSV с эталонами:
    python transcribe.py --model ./experiments/whisper-small-ru/final \
        --csv ./data/val_asr.csv \
        --base_dir ./data \
        --language russian
"""

import argparse
import csv
import os
import sys
import time
from pathlib import Path
from typing import List, Optional, Tuple

import torch
import torchaudio
from transformers import WhisperForConditionalGeneration, WhisperProcessor

from src.text_normalize import normalize
from src.metrics import wer_report


SUPPORTED_EXTENSIONS = {".wav", ".flac", ".mp3", ".ogg", ".opus", ".m4a"}


def load_audio(path: str, target_sr: int = 16000) -> torch.Tensor:
    """Загружает аудио в моно 16kHz."""
    waveform, sr = torchaudio.load(path)
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)
    if sr != target_sr:
        waveform = torchaudio.functional.resample(waveform, sr, target_sr)
    return waveform.squeeze(0)


def find_audio_files(directory: str) -> List[str]:
    """Рекурсивно находит все аудиофайлы в директории."""
    files = []
    for path in sorted(Path(directory).rglob("*")):
        if path.suffix.lower() in SUPPORTED_EXTENSIONS:
            files.append(str(path))
    return files


class WhisperTranscriber:
    """
    Обёртка над обученной Whisper-моделью для инференса.

    Параметры:
        model_path: путь к директории с сохранённой моделью (после train_whisper.py)
                    или имя HuggingFace модели ("openai/whisper-small")
        language:   язык транскрипции ("russian", "english", ...)
        device:     "cuda", "cpu", или "auto"
        batch_size: число файлов в батче (больше = быстрее, но больше памяти)
    """

    def __init__(
        self,
        model_path: str,
        language: str = "russian",
        device: str = "auto",
        batch_size: int = 8,
    ):
        if device == "auto":
            device = "cuda" if torch.cuda.is_available() else "cpu"

        print(f"[INFO] Загружаем модель из: {model_path}")
        print(f"[INFO] Устройство: {device}")

        self.processor = WhisperProcessor.from_pretrained(model_path, language=language, task="transcribe")
        self.model = WhisperForConditionalGeneration.from_pretrained(model_path)
        self.model.to(device)
        self.model.eval()

        self.device = device
        self.batch_size = batch_size
        self.language = language

        # Принудительно задаём язык
        self.forced_decoder_ids = self.processor.get_decoder_prompt_ids(
            language=language, task="transcribe"
        )

        print(f"[INFO] Модель загружена. Язык: {language}\n")

    @torch.no_grad()
    def transcribe_batch(self, waveforms: List[torch.Tensor]) -> List[str]:
        """Транскрибирует список waveform-тензоров."""
        # Извлекаем log-mel признаки
        inputs = self.processor.feature_extractor(
            [w.numpy() for w in waveforms],
            sampling_rate=16000,
            return_tensors="pt",
            padding=True,
        )
        input_features = inputs.input_features.to(self.device)

        # Генерация
        predicted_ids = self.model.generate(
            input_features,
            forced_decoder_ids=self.forced_decoder_ids,
            max_new_tokens=225,
        )

        # Декодирование
        transcriptions = self.processor.batch_decode(predicted_ids, skip_special_tokens=True)
        return transcriptions

    def transcribe_files(
        self,
        audio_paths: List[str],
        normalize_output: bool = True,
        verbose: bool = True,
    ) -> List[Tuple[str, str]]:
        """
        Транскрибирует список аудиофайлов батчами.

        Возвращает список пар (filepath, transcript).
        """
        results = []
        total = len(audio_paths)
        t0 = time.perf_counter()

        for i in range(0, total, self.batch_size):
            batch_paths = audio_paths[i: i + self.batch_size]

            # Загружаем аудио
            waveforms = []
            valid_paths = []
            for path in batch_paths:
                try:
                    w = load_audio(path)
                    waveforms.append(w)
                    valid_paths.append(path)
                except Exception as e:
                    print(f"[WARN] Не удалось загрузить {path}: {e}", file=sys.stderr)

            if not waveforms:
                continue

            transcriptions = self.transcribe_batch(waveforms)

            for path, text in zip(valid_paths, transcriptions):
                if normalize_output:
                    text = normalize(text)
                results.append((path, text))

                if verbose:
                    print(f"[{len(results):4d}/{total}] {Path(path).name}: {text}")

        elapsed = time.perf_counter() - t0
        rtf = elapsed / max(total, 1)
        print(f"\n[INFO] Обработано {len(results)} файлов за {elapsed:.1f}с ({rtf:.2f}с/файл)")

        return results


def main():
    parser = argparse.ArgumentParser(description="Транскрибирование аудио обученной Whisper-моделью")
    parser.add_argument("--model", required=True, help="Путь к модели или HuggingFace ID")
    parser.add_argument("--audio", help="Путь к одному аудиофайлу")
    parser.add_argument("--audio_dir", help="Директория с аудиофайлами (рекурсивно)")
    parser.add_argument("--csv", help="CSV с колонками filepath,transcript (для оценки WER)")
    parser.add_argument("--base_dir", default=".", help="Корневая папка для путей из CSV")
    parser.add_argument("--output", help="Выходной CSV (filepath,transcript)")
    parser.add_argument("--language", default="russian", help="Язык транскрипции")
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--no_normalize", action="store_true", help="Не нормализовать выход")
    args = parser.parse_args()

    transcriber = WhisperTranscriber(
        model_path=args.model,
        language=args.language,
        device=args.device,
        batch_size=args.batch_size,
    )

    # --- Режим: CSV с эталонами → WER ---
    if args.csv:
        import pandas as pd
        df = pd.read_csv(args.csv)
        assert "filepath" in df.columns and "transcript" in df.columns

        paths = []
        for p in df["filepath"]:
            if not os.path.isabs(p):
                p = os.path.normpath(os.path.join(args.base_dir, p))
            paths.append(p)

        results = transcriber.transcribe_files(paths, normalize_output=not args.no_normalize)

        predictions = [r[1] for r in results]
        references = df["transcript"].astype(str).tolist()

        print("\n" + "="*60)
        print(wer_report(predictions, references, n_examples=5))
        print("="*60)

        if args.output:
            with open(args.output, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["filepath", "prediction", "reference"])
                for (path, pred), ref in zip(results, references):
                    writer.writerow([path, pred, ref])
            print(f"\n[INFO] Результаты сохранены: {args.output}")
        return

    # --- Режим: один файл ---
    if args.audio:
        results = transcriber.transcribe_files(
            [args.audio], normalize_output=not args.no_normalize
        )
        print(f"\nТранскрипция: {results[0][1]}")
        return

    # --- Режим: директория ---
    if args.audio_dir:
        files = find_audio_files(args.audio_dir)
        if not files:
            print(f"[ERROR] Аудиофайлы не найдены в: {args.audio_dir}", file=sys.stderr)
            sys.exit(1)

        print(f"[INFO] Найдено {len(files)} файлов в {args.audio_dir}\n")
        results = transcriber.transcribe_files(files, normalize_output=not args.no_normalize)

        if args.output:
            with open(args.output, "w", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow(["filepath", "transcript"])
                writer.writerows(results)
            print(f"[INFO] Результаты сохранены: {args.output}")
        return

    parser.print_help()


if __name__ == "__main__":
    main()
