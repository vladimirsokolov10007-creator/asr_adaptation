# ASR на базе Whisper — рабочий пайплайн

Полный пайплайн **распознавания русской речи** на основе fine-tuning OpenAI Whisper.

## Почему Whisper, а не ECAPA-CTC с нуля

| Критерий | ECAPA-CTC (v1) | Whisper fine-tuning (v2) |
|---|---|---|
| Архитектура | Верификация дикторов, адаптированная под ASR | Encoder-Decoder, обученный именно на ASR |
| Предобучение | Нет | 680 000 часов речи, включая русский |
| WER на русском | 60–80% (теоретический минимум без LM) | 5–15% после fine-tuning |
| Языковая модель | Нужна отдельно (pyctcdecode + kenlm) | Встроена в декодер |
| Время до рабочего результата | Недели обучения | 2–8 часов на одной GPU |

## Структура проекта

```
asr_v2/
├── src/
│   ├── text_normalize.py   ← нормализация текста (числа → слова, пунктуация)
│   ├── whisper_dataset.py  ← датасет для Seq2SeqTrainer
│   ├── noise_augment.py    ← шум + реверб + смена скорости
│   └── metrics.py          ← WER, CER, отчёт с примерами
│
├── configs/
│   ├── whisper_small.json      ← 8–12 GB VRAM, WER ~8-12%
│   ├── whisper_medium.json     ← 24+ GB VRAM, WER ~4-7%
│   └── whisper_tiny_cpu.json   ← CPU / тест пайплайна
│
├── train_whisper.py    ← скрипт обучения
├── transcribe.py       ← инференс (файл / директория / оценка WER)
├── requirements.txt
└── README.md
```

## Быстрый старт

### 1. Установка зависимостей

```bash
pip install -r requirements.txt

# Для аугментации скоростью нужен sox:
# Ubuntu: sudo apt-get install sox
# macOS:  brew install sox
```

### 2. Подготовка данных

Нужен CSV с двумя колонками:

```csv
filepath,transcript
data/train/audio001.flac,привет как дела
data/train/audio002.flac,сегодня хорошая погода
```

**Вариант А: разметка через Whisper** (если нет ручных транскрипций)

```bash
# Из папки asr_adaptation (шаги 1-3 оригинального проекта):
python step1_download_noise_data.py --out_dir ./data
python step3_transcribe.py \
    --audio_dir ./data/train \
    --out_dir   ./data \
    --language  ru \
    --model_size medium   # medium или large-v3 для лучшей разметки
```

> ⚠️ Если разметка через Whisper, **используйте для разметки модель большего размера**
> чем та, что будете дообучать. Например: разметка через `large-v3`, обучение `small`.
> Иначе модель учится повторять свои же ошибки.

**Вариант Б: готовые датасеты** (рекомендуется)

```python
# Common Voice 16.0 — 700+ часов русской речи с ручной разметкой
from datasets import load_dataset
ds = load_dataset("mozilla-foundation/common_voice_16_0", "ru", split="train")
# Экспортируйте в CSV формат filepath,transcript
```

### 3. Шумовые данные (опционально, но рекомендуется)

```bash
# MUSAN (~11 GB): фоновые шумы
# https://openslr.org/17/

# OpenSLR RIRs (~1 GB): реверберация
# https://openslr.org/28/
```

Если шумов нет — уберите `noise_dir` и `rir_dir` из конфига (или поставьте `null`).

### 4. Обучение

Выберите конфиг под ваше железо:

```bash
# GPU 8-12 GB (RTX 3080/4070, A10G):
python train_whisper.py --config configs/whisper_small.json

# GPU 24+ GB (A100, RTX 4090):
python train_whisper.py --config configs/whisper_medium.json

# CPU или тест пайплайна (медленно):
python train_whisper.py --config configs/whisper_tiny_cpu.json
```

Прогресс и WER логируются каждые `eval_steps` шагов. Лучшая модель сохраняется автоматически.

### 5. Инференс

```bash
# Один файл:
python transcribe.py --model ./experiments/whisper-small-ru/final --audio audio.wav

# Директория → CSV:
python transcribe.py \
    --model ./experiments/whisper-small-ru/final \
    --audio_dir ./data/test \
    --output results.csv

# Оценка WER на валидационном CSV:
python transcribe.py \
    --model ./experiments/whisper-small-ru/final \
    --csv ./data/val_asr.csv \
    --base_dir ./data
```

## Ожидаемые результаты

| Модель | Параметры | GPU | Время обучения* | WER (чистая речь) |
|---|---|---|---|---|
| whisper-tiny | 39 M | CPU / 4 GB | ~30 мин | 25–35% |
| whisper-small | 244 M | 8 GB | ~2–4 ч | 8–12% |
| whisper-medium | 769 M | 24 GB | ~4–8 ч | 4–7% |
| whisper-large-v3 | 1550 M | 40 GB | ~8–16 ч | 2–5% |

\* при датасете ~100 часов речи, 10 эпох

## Ключевые компоненты

### Нормализация текста (`src/text_normalize.py`)

Обеспечивает единый формат транскрипций из разных источников:

```python
from src.text_normalize import normalize

normalize("Привет, как дела? Мне 25 лет.")
# → "привет как дела мне двадцать пять лет"

normalize("В 2024 году было 365 дней.")
# → "в две тысячи двадцать четыре году было триста шестьдесят пять дней"
```

### Метрики (`src/metrics.py`)

```python
from src.metrics import compute_wer, compute_cer, wer_report

wer = compute_wer(predictions, references)   # 0.0 = идеально
cer = compute_cer(predictions, references)   # посимвольная версия

print(wer_report(predictions, references, n_examples=5))
```

### Аугментация (`src/noise_augment.py`)

Применяется только при обучении. Без шумовых данных (`noise_dir=null`) работает только аугментация скоростью.

## Настройка конфига

Ключевые параметры `configs/whisper_small.json`:

| Параметр | Описание | Рекомендация |
|---|---|---|
| `model_name` | Размер Whisper | `whisper-small` для старта |
| `lr` | Learning rate | 1e-5 для small, 5e-6 для medium |
| `batch_size` × `gradient_accumulation_steps` | Эффективный батч | 16–32 |
| `warmup_steps` | Шаги прогрева | 500 (5–10% от total_steps) |
| `eval_steps` | Частота оценки | 500 |
| `noise_prob` | Вероятность шума | 0.5 (меньше чем в v1 — Whisper робастнее) |
| `snr_min` | Минимальный SNR | 5 (не 0 — иначе речь неразборчива) |

## Возобновление обучения

```json
{
  "resume_from_checkpoint": "./experiments/whisper-small-ru/checkpoint-1500"
}
```

## Ускорение инференса (опционально)

После обучения модель можно конвертировать в faster-whisper для продакшена:

```bash
pip install faster-whisper

# Конвертация:
ct2-opus-mt-converter --model ./experiments/whisper-small-ru/final \
    --output_dir ./experiments/whisper-small-ru-ct2 \
    --quantization int8

# Инференс в 2-4× быстрее:
from faster_whisper import WhisperModel
model = WhisperModel("./experiments/whisper-small-ru-ct2", device="cpu", compute_type="int8")
segments, info = model.transcribe("audio.wav", language="ru")
```
