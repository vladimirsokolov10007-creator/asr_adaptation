# Быстрый старт: шаги 1–3

Положи эти скрипты в корень папки `asr_adaptation/` рядом с `train_asr.py`.

---

## Шаг 1 — Скачать шумовые данные

```bash
python step1_download_noise_data.py --out_dir ./data
```

Скачает ~11 ГБ:
- `./data/musan/noise/` — фоновые шумы для аугментации
- `./data/openslr_rirs/` — импульсные отклики для реверберации

Если нужны только шумы (без реверба):
```bash
python step1_download_noise_data.py --out_dir ./data --skip_rirs
```

---

## Шаг 2 — Создать окружение

```bash
chmod +x step2_setup_env.sh
./step2_setup_env.sh

# Активировать перед каждой работой:
source venv/bin/activate
```

---

## Шаг 3 — Разметить аудио через Whisper

```bash
# Быстрый тест на 50 файлах (модель tiny, ~2 мин):
python step3_transcribe.py \
    --audio_dir  ./data/train \
    --out_dir    ./data \
    --language   ru \
    --model_size tiny \
    --max_files  50

# Полная разметка (модель medium, несколько часов):
python step3_transcribe.py \
    --audio_dir  ./data/train \
    --out_dir    ./data \
    --language   ru \
    --model_size medium
```

Результат: `./data/train_asr.csv` и `./data/val_asr.csv`

---

## Шаг 4 — Проверить конфиг и запустить обучение

Убедись что в `configs/asr.json` правильные пути:
```json
"noise_dir": "./data/musan/noise",
"rir_dir":   "./data/openslr_rirs",
"train_csv": "./data/train_asr.csv",
"val_csv":   "./data/val_asr.csv"
```

Затем:
```bash
python train_asr.py --config configs/asr.json
```

---

## Структура папки после всех шагов

```
asr_adaptation/
├── data/
│   ├── musan/noise/          ← шумы (шаг 1)
│   ├── openslr_rirs/         ← реверберация (шаг 1)
│   ├── train/                ← твои аудиофайлы
│   ├── train_asr.csv         ← разметка (шаг 3)
│   └── val_asr.csv           ← разметка (шаг 3)
├── src/
├── configs/asr.json
├── train_asr.py
├── step1_download_noise_data.py
├── step2_setup_env.sh
└── step3_transcribe.py
```
