"""
ASR-модель: ECAPA-TDNN энкодер из бейзлайна + CTC-голова для расшифровки речи.

Архитектура:
    MelFrontend  →  ECAPA-TDNN (без пулинга)  →  Linear (vocab_size)  →  CTC Loss

Ключевое отличие от оригинала:
    - Убираем ASTP-пулинг (он сворачивал временную ось в один вектор)
    - Добавляем временной CTC-классификатор поверх фреймов
    - Размерность выхода = vocab_size (количество символов + blank)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .mel_frontend import MelFrontend
from .asr_dataset import VOCAB_SIZE, BLANK_IDX


# ---- Переиспользуем блоки из оригинального ecapa.py без изменений ----

class Conv1dReluBn(nn.Module):
    def __init__(self, in_ch, out_ch, kernel_size=1, stride=1, padding=0, dilation=1):
        super().__init__()
        self.conv = nn.Conv1d(in_ch, out_ch, kernel_size, stride, padding, dilation)
        self.bn = nn.BatchNorm1d(out_ch)

    def forward(self, x):
        return self.bn(F.relu(self.conv(x)))


class Res2Conv1dReluBn(nn.Module):
    def __init__(self, channels, kernel_size=1, stride=1, padding=0, dilation=1, scale=4):
        super().__init__()
        assert channels % scale == 0
        self.scale = scale
        self.width = channels // scale
        self.nums = scale if scale == 1 else scale - 1
        self.convs = nn.ModuleList([
            nn.Conv1d(self.width, self.width, kernel_size, stride, padding, dilation)
            for _ in range(self.nums)
        ])
        self.bns = nn.ModuleList([nn.BatchNorm1d(self.width) for _ in range(self.nums)])

    def forward(self, x):
        out, spx, sp = [], torch.split(x, self.width, 1), None
        for i, (conv, bn) in enumerate(zip(self.convs, self.bns)):
            sp = spx[i] if i == 0 else sp + spx[i]
            sp = bn(F.relu(conv(sp)))
            out.append(sp)
        if self.scale != 1:
            out.append(spx[self.nums])
        return torch.cat(out, dim=1)


class SE_Connect(nn.Module):
    def __init__(self, channels, bottleneck=128):
        super().__init__()
        self.l1 = nn.Linear(channels, bottleneck)
        self.l2 = nn.Linear(bottleneck, channels)

    def forward(self, x):
        out = F.relu(self.l1(x.mean(dim=2)))
        return x * torch.sigmoid(self.l2(out)).unsqueeze(2)


class SE_Res2Block(nn.Module):
    def __init__(self, channels, kernel_size, stride, padding, dilation, scale):
        super().__init__()
        self.block = nn.Sequential(
            Conv1dReluBn(channels, channels),
            Res2Conv1dReluBn(channels, kernel_size, stride, padding, dilation, scale=scale),
            Conv1dReluBn(channels, channels),
            SE_Connect(channels),
        )

    def forward(self, x):
        return x + self.block(x)


# ---- ECAPA без пулинга: выдаёт (B, channels*3, T) вместо эмбеддинга ----

class ECAPA_TDNN_Encoder(nn.Module):
    """
    ECAPA-TDNN без финального пулинга.
    Вход:  (B, T, n_mels)
    Выход: (B, T, out_channels)  — фреймовые признаки для CTC
    """
    def __init__(self, feat_dim: int = 80, channels: int = 512):
        super().__init__()
        self.layer1 = Conv1dReluBn(feat_dim, channels, kernel_size=5, padding=2)
        self.layer2 = SE_Res2Block(channels, kernel_size=3, stride=1, padding=2, dilation=2, scale=8)
        self.layer3 = SE_Res2Block(channels, kernel_size=3, stride=1, padding=3, dilation=3, scale=8)
        self.layer4 = SE_Res2Block(channels, kernel_size=3, stride=1, padding=4, dilation=4, scale=8)
        self.conv_cat = nn.Conv1d(channels * 3, channels, kernel_size=1)
        self.out_dim = channels

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.permute(0, 2, 1)          # (B, n_mels, T)
        out1 = self.layer1(x)
        out2 = self.layer2(out1)
        out3 = self.layer3(out2)
        out4 = self.layer4(out3)
        out = F.relu(self.conv_cat(torch.cat([out2, out3, out4], dim=1)))
        return out.permute(0, 2, 1)      # (B, T, channels)


# ---- Полная ASR-модель ----

class ECAPAAsrModel(nn.Module):
    """
    Полная ASR-модель для CTC-обучения.

    Использует MelFrontend и ECAPA_TDNN_Encoder из бейзлайна,
    добавляет линейный CTC-классификатор поверх временных фреймов.

    Параметры:
        sample_rate, n_fft, hop_length, n_mels — аудио-параметры (как в конфиге)
        channels    — ширина ECAPA (512 в бейзлайне)
        vocab_size  — размер словаря символов + blank (из asr_dataset.py)

    Использование:
        model = ECAPAAsrModel(...)
        log_probs, input_lengths = model(waveform)   # для CTC Loss
        # или
        text = model.decode_greedy(waveform)         # жадная расшифровка
    """

    def __init__(
        self,
        sample_rate: int = 16000,
        n_fft: int = 400,
        hop_length: int = 160,
        n_mels: int = 80,
        channels: int = 512,
        vocab_size: int = VOCAB_SIZE,
    ):
        super().__init__()
        self.hop_length = hop_length
        self.frontend = MelFrontend(sample_rate, n_fft, hop_length, n_mels)
        self.encoder = ECAPA_TDNN_Encoder(feat_dim=n_mels, channels=channels)
        self.ctc_head = nn.Linear(channels, vocab_size)
        self.vocab_size = vocab_size

    def forward(self, waveform: torch.Tensor):
        """
        Вход:  waveform (B, T_audio)
        Выход: log_probs    (T_frames, B, vocab_size)  — для nn.CTCLoss
               input_lengths (B,)                      — длины фреймов
        """
        feats = self.frontend(waveform)            # (B, T_frames, n_mels)
        encoded = self.encoder(feats)              # (B, T_frames, channels)
        logits = self.ctc_head(encoded)            # (B, T_frames, vocab_size)
        log_probs = F.log_softmax(logits, dim=-1)  # (B, T_frames, vocab_size)
        log_probs = log_probs.permute(1, 0, 2)    # (T_frames, B, vocab_size)

        # Длина фреймов одинакова для всех (аудио нарезано в датасете)
        T = log_probs.shape[0]
        input_lengths = torch.full((waveform.shape[0],), T, dtype=torch.long)

        return log_probs, input_lengths

    @torch.no_grad()
    def decode_greedy(self, waveform: torch.Tensor) -> list:
        """
        Жадная CTC-расшифровка без языковой модели.
        Возвращает список строк для каждого примера в батче.
        """
        from .asr_dataset import IDX_TO_CHAR
        log_probs, _ = self.forward(waveform)          # (T, B, V)
        pred_ids = log_probs.argmax(dim=-1).T          # (B, T)

        results = []
        for seq in pred_ids:
            # CTC collapse: убрать повторы и blank
            chars = []
            prev = BLANK_IDX
            for idx in seq.tolist():
                if idx != BLANK_IDX and idx != prev:
                    chars.append(IDX_TO_CHAR.get(idx, ""))
                prev = idx
            results.append("".join(chars))
        return results
