# Запуск на Windows + NVIDIA GPU

## Подготовка (один раз)

### 1. Установи Python 3.11
Скачай с https://www.python.org/downloads/
При установке обязательно поставь галочку **"Add Python to PATH"**

Проверь в PowerShell:
```
python --version
```
Должно вывести `Python 3.11.x`

### 2. Установи CUDA Toolkit 12.4
Скачай с https://developer.nvidia.com/cuda-12-4-0-download-archive
Выбери: Windows → x86_64 → exe (local)

Проверь после установки:
```
nvcc --version
```

### 3. Распакуй архив
Распакуй `asr_adaptation_full.zip` в удобное место, например:
```
C:\projects\asr_adaptation\
```

---

## Шаг 2 — Создать окружение (замена step2_setup_env.sh)

В PowerShell перейди в папку проекта:
```powershell
cd C:\projects\asr_adaptation
```

Создай виртуальное окружение:
```powershell
python -m venv venv
venv\Scripts\activate
```

После активации в начале строки появится `(venv)`.

Установи PyTorch с поддержкой CUDA 12.4:
```powershell
pip install torch==2.7.0 torchaudio==2.7.0 --extra-index-url https://download.pytorch.org/whl/cu124
```

Установи остальные зависимости:
```powershell
pip install numpy pandas==2.2.2 soundfile==0.12.1 tqdm==4.66.6 onnx onnxruntime-gpu openai-whisper pyctcdecode jiwer datasets huggingface_hub faiss-cpu
```

Проверь что GPU виден:
```powershell
python -c "import torch; print(torch.cuda.is_available(), torch.cuda.get_device_name(0))"
```
Должно вывести `True  NVIDIA GeForce ...`

---

## Шаг 1 — Скачать шумовые данные

```powershell
python step1_download_noise_data.py --out_dir .\data
```

Скачает ~11 ГБ. Можно запустить параллельно пока идёт установка зависимостей.

Если нужно только проверить пайплайн без реальных шумов — пропусти этот шаг
и в `configs\asr.json` убери строки `noise_dir` и `rir_dir` (аугментация просто не применится).

---

## Шаг 3 — Разметить аудио через Whisper

Сначала быстрый тест на 50 файлах (~3 минуты на GPU):
```powershell
python step3_transcribe.py `
    --audio_dir .\data\train `
    --out_dir   .\data `
    --language  ru `
    --model_size tiny `
    --max_files 50
```

Если всё работает — полная разметка:
```powershell
python step3_transcribe.py `
    --audio_dir  .\data\train `
    --out_dir    .\data `
    --language   ru `
    --model_size medium
```

---

## Шаг 4 — Обучение

```powershell
python train_asr.py --config configs\asr.json
```

---

## Частые проблемы на Windows

**"python не является внутренней командой"**
→ При установке Python не была поставлена галочка "Add to PATH".
  Переустанови Python или добавь путь вручную в переменные среды.

**"venv\Scripts\activate не найден"**
→ Запусти PowerShell от имени администратора и выполни:
  `Set-ExecutionPolicy RemoteSigned`

**CUDA не видна (torch.cuda.is_available() = False)**
→ Убедись что установлен CUDA Toolkit 12.4 и драйвер NVIDIA свежий (550+).
  Скачать драйвер: https://www.nvidia.com/drivers

**Ошибка при установке faiss-cpu на Windows**
→ Замени на: `pip install faiss-cpu --no-cache-dir`
