#!/usr/bin/env bash
# =============================================================================
# Шаг 2 — Создать виртуальное окружение и установить все зависимости.
#
# Запуск:
#   chmod +x step2_setup_env.sh
#   ./step2_setup_env.sh
#
# После запуска активируй окружение:
#   source venv/bin/activate
# =============================================================================

set -e  # остановиться при любой ошибке

VENV_DIR="./venv"
PYTHON="python3"

echo "=============================="
echo " Шаг 2: Настройка окружения"
echo "=============================="

# Проверяем Python
if ! command -v $PYTHON &>/dev/null; then
    echo "[ERR] Python3 не найден. Установи Python 3.10+"
    exit 1
fi

PY_VER=$($PYTHON -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo "[INFO] Найден Python $PY_VER"

# Создаём venv
if [ -d "$VENV_DIR" ]; then
    echo "[SKIP] Виртуальное окружение уже существует: $VENV_DIR"
else
    echo "[INFO] Создаём окружение: $VENV_DIR"
    $PYTHON -m venv $VENV_DIR
fi

source $VENV_DIR/bin/activate
echo "[INFO] Окружение активировано"

# Обновляем pip
pip install --upgrade pip -q

# Основные зависимости из оригинального бейзлайна
echo "[INFO] Устанавливаем PyTorch + torchaudio..."
pip install torch==2.7.0 torchaudio==2.7.0 \
    --extra-index-url https://download.pytorch.org/whl/cu124 -q

echo "[INFO] Устанавливаем остальные зависимости..."
pip install \
    faiss-cpu==1.13.2 \
    numpy \
    pandas==2.2.2 \
    soundfile==0.12.1 \
    tqdm==4.66.6 \
    onnx \
    onnxruntime -q

# Дополнительно для ASR
echo "[INFO] Устанавливаем дополнения для ASR..."
pip install \
    openai-whisper \
    pyctcdecode \
    jiwer \
    datasets \
    huggingface_hub -q

echo ""
echo "[ГОТОВО] Все зависимости установлены."
echo ""
echo "Для активации окружения в будущем:"
echo "    source $VENV_DIR/bin/activate"
echo ""
echo "Проверка установки:"
$PYTHON -c "import torch, torchaudio, whisper; print(f'torch={torch.__version__}, torchaudio={torchaudio.__version__}, CUDA={torch.cuda.is_available()}')"
