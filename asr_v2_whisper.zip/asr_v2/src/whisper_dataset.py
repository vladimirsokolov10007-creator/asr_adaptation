"""
Датасет для fine-tuning Whisper.

Отличия от оригинального asr_dataset.py:
  - Использует WhisperProcessor (токенизация + log-mel фронтенд от OpenAI)
  - Нормализует текст через text_normalize.normalize()
  - Не нарезает аудио на фиксированные чанки — Whisper сам работает с 30-секундными окнами
  - Поддерживает NoiseAugmentor из оригинального проекта
  - collate_fn возвращает input_features + labels для Seq2SeqTrainer
"""

import os
import random
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
import torch
import torchaudio
from torch.utils.data import Dataset
from transformers import WhisperProcessor

from .text_normalize import normalize
from .noise_augment import NoiseAugmentor


# Whisper обучен на 30-секундных окнах при sr=16000
WHISPER_SAMPLE_RATE = 16_000
WHISPER_MAX_SAMPLES = 30 * WHISPER_SAMPLE_RATE   # 480 000 сэмплов


def load_audio(filepath: str, target_sr: int = WHISPER_SAMPLE_RATE) -> torch.Tensor:
    """Загружает аудиофайл, конвертирует в моно и нужную частоту дискретизации."""
    waveform, sr = torchaudio.load(filepath)
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)
    if sr != target_sr:
        waveform = torchaudio.functional.resample(waveform, sr, target_sr)
    return waveform.squeeze(0)   # (T,)


def pad_or_trim(waveform: torch.Tensor, max_samples: int = WHISPER_MAX_SAMPLES) -> torch.Tensor:
    """
    Обрезает или дополняет нулями до max_samples.
    Whisper ожидает ровно 30 секунд — processor делает это сам,
    но явное приведение здесь помогает при аугментации скоростью.
    """
    if len(waveform) > max_samples:
        # Случайная вырезка при обучении (вместо обрезки с начала)
        start = random.randint(0, len(waveform) - max_samples)
        return waveform[start: start + max_samples]
    return waveform   # processor дополнит нулями сам


class WhisperASRDataset(Dataset):
    """
    Датасет для fine-tuning Whisper через Seq2SeqTrainer.

    CSV должен содержать колонки:
        filepath    — путь к аудиофайлу (.flac/.wav)
        transcript  — текстовая расшифровка

    Параметры:
        csv_path:        путь к CSV
        processor:       WhisperProcessor (токенизатор + feature extractor)
        is_train:        True → случайная вырезка и аугментация
        base_dir:        корневая папка для относительных путей из CSV
        augmentor:       NoiseAugmentor (опционально, только при is_train=True)
        language:        язык для Whisper (например "russian", "english")
        max_chars:       фильтр: выбрасывать транскрипции длиннее N символов
                         (после нормализации). 0 = без фильтра.
    """

    def __init__(
        self,
        csv_path: str,
        processor: WhisperProcessor,
        is_train: bool = True,
        base_dir: Optional[str] = None,
        augmentor: Optional[NoiseAugmentor] = None,
        language: str = "russian",
        max_chars: int = 400,
    ):
        df = pd.read_csv(csv_path)
        assert "filepath" in df.columns, "CSV должен содержать колонку 'filepath'"
        assert "transcript" in df.columns, "CSV должен содержать колонку 'transcript'"

        # Нормализуем транскрипции сразу при загрузке
        df["transcript"] = df["transcript"].astype(str).apply(normalize)

        # Фильтрация пустых и слишком длинных (Whisper токенизатор имеет лимит)
        df = df[df["transcript"].str.len() > 0]
        if max_chars > 0:
            before = len(df)
            df = df[df["transcript"].str.len() <= max_chars]
            dropped = before - len(df)
            if dropped:
                print(f"[WhisperDataset] Отфильтровано {dropped} слишком длинных примеров (>{max_chars} символов)")

        self.df = df.reset_index(drop=True)
        self.processor = processor
        self.is_train = is_train
        self.base_dir = base_dir
        self.augmentor = augmentor if is_train else None
        self.language = language

        print(f"[WhisperDataset] {'Train' if is_train else 'Val'}: {len(self.df)} примеров")

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        row = self.df.iloc[idx]

        # Путь к файлу
        path = row["filepath"]
        if not os.path.isabs(path) and self.base_dir:
            path = os.path.normpath(os.path.join(self.base_dir, path))

        # Загрузка аудио
        waveform = load_audio(path)

        # Аугментация (только при обучении)
        if self.augmentor is not None:
            waveform = self.augmentor(waveform)

        # Обрезка до 30 сек (случайная при обучении)
        if self.is_train:
            waveform = pad_or_trim(waveform)

        # WhisperProcessor → log-mel спектрограмма
        # processor.feature_extractor дополнит нулями до 30 сек автоматически
        input_features = self.processor.feature_extractor(
            waveform.numpy(),
            sampling_rate=WHISPER_SAMPLE_RATE,
            return_tensors="pt",
        ).input_features[0]   # (80, 3000)

        # Токенизация транскрипции
        labels = self.processor.tokenizer(
            row["transcript"],
            return_tensors="pt",
        ).input_ids[0]   # (L,)

        return {
            "input_features": input_features,
            "labels": labels,
        }


class WhisperDataCollator:
    """
    Collate-функция для Seq2SeqTrainer.

    - input_features: паддинг до одинаковой длины (все 30 сек → уже одинаковые)
    - labels: паддинг до максимальной длины в батче, -100 на паддинговые позиции
              (-100 игнорируется CrossEntropyLoss)
    """

    def __init__(self, processor: WhisperProcessor):
        self.processor = processor

    def __call__(self, features: List[Dict]) -> Dict[str, torch.Tensor]:
        # input_features уже одинакового размера (80, 3000) → просто стек
        input_features = torch.stack([f["input_features"] for f in features])

        # labels — переменная длина → паддинг
        label_ids = [f["labels"] for f in features]
        max_len = max(l.shape[0] for l in label_ids)
        padded_labels = torch.full((len(label_ids), max_len), fill_value=-100, dtype=torch.long)
        for i, lab in enumerate(label_ids):
            padded_labels[i, :lab.shape[0]] = lab

        return {
            "input_features": input_features,
            "labels": padded_labels,
        }
