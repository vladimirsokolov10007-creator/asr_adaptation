"""
Шаг 1 — Скачать шумовые данные: MUSAN + OpenSLR RIRs.

Запуск:
    python step1_download_noise_data.py --out_dir ./data

Что скачивается:
    ./data/musan/          — ~10 ГБ, фоновые шумы (music / noise / speech)
    ./data/openslr_rirs/   — ~1 ГБ, импульсные отклики (реверберация)

После скачивания в configs/asr.json укажи:
    "noise_dir": "./data/musan/noise",
    "rir_dir":   "./data/openslr_rirs"
"""

import argparse
import os
import tarfile
import urllib.request
from pathlib import Path


MUSAN_URL = "https://openslr.org/resources/17/musan.tar.gz"
RIR_URL   = "https://openslr.org/resources/28/rirs_noises.zip"


def download(url: str, dest: Path):
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        print(f"[SKIP] Уже скачан: {dest}")
        return
    print(f"[DOWN] {url}")
    print(f"       → {dest}")

    def _progress(block_num, block_size, total_size):
        downloaded = block_num * block_size
        if total_size > 0:
            pct = min(100, downloaded * 100 // total_size)
            mb = downloaded / 1024 / 1024
            total_mb = total_size / 1024 / 1024
            print(f"\r       {pct}%  {mb:.0f} / {total_mb:.0f} МБ", end="", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)
    print()


def extract_tar(archive: Path, out_dir: Path):
    print(f"[UNPACK] {archive.name} → {out_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, "r:gz") as tar:
        tar.extractall(out_dir)


def extract_zip(archive: Path, out_dir: Path):
    import zipfile
    print(f"[UNPACK] {archive.name} → {out_dir}")
    out_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, "r") as z:
        z.extractall(out_dir)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", default="./data", help="Куда сохранять данные")
    parser.add_argument("--skip_musan", action="store_true", help="Пропустить MUSAN")
    parser.add_argument("--skip_rirs",  action="store_true", help="Пропустить RIRs")
    args = parser.parse_args()

    out = Path(args.out_dir)

    # --- MUSAN ---
    if not args.skip_musan:
        musan_archive = out / "musan.tar.gz"
        musan_dir     = out / "musan"
        if musan_dir.exists():
            print(f"[SKIP] MUSAN уже распакован: {musan_dir}")
        else:
            download(MUSAN_URL, musan_archive)
            extract_tar(musan_archive, out)
            musan_archive.unlink()   # удаляем архив чтобы сэкономить место
        print(f"[OK] MUSAN → {musan_dir}")
        print(f"     Папки: {[p.name for p in musan_dir.iterdir() if p.is_dir()]}")
    else:
        print("[SKIP] MUSAN пропущен")

    # --- OpenSLR RIRs ---
    if not args.skip_rirs:
        rir_archive = out / "rirs_noises.zip"
        rir_dir     = out / "openslr_rirs"
        if rir_dir.exists():
            print(f"[SKIP] RIRs уже распакован: {rir_dir}")
        else:
            download(RIR_URL, rir_archive)
            extract_zip(rir_archive, rir_dir)
            rir_archive.unlink()
        print(f"[OK] OpenSLR RIRs → {rir_dir}")
    else:
        print("[SKIP] RIRs пропущены")

    # --- Итог ---
    print("\n[ГОТОВО] Вставь в configs/asr.json:")
    print(f'    "noise_dir": "{out / "musan" / "noise"}",')
    print(f'    "rir_dir":   "{out / "openslr_rirs"}"')


if __name__ == "__main__":
    main()
