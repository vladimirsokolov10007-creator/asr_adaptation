"""
Датасет для ASR (расшифровка речи) с поддержкой шумовой аугментации.
Расширяет логику SpeakerDataset из оригинального бейзлайна:
  - вместо speaker_id предсказывает текстовую транскрипцию (для CTC)
  - поддерживает NoiseAugmentor при is_train=True
"""

import os
import random
from typing import List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torchaudio
from torch.utils.data import Dataset

from .noise_augment import NoiseAugmentor


# ---------- Словарь символов (русский + латинский + служебные) ----------
# Адаптируй под свой язык. Индекс 0 зарезервирован под CTC blank token.
BLANK_IDX = 0
CHARS = list(" абвгдеёжзийклмнопрстуфхцчшщъыьэюя")  # 34 символа + пробел
CHAR_TO_IDX = {c: i + 1 for i, c in enumerate(CHARS)}   # 1-based, 0 = blank
IDX_TO_CHAR = {i + 1: c for i, c in enumerate(CHARS)}
VOCAB_SIZE = len(CHARS) + 1  # +1 для blank


def text_to_indices(text: str) -> List[int]:
    """Переводит строку в список индексов символов. Неизвестные символы пропускаются."""
    text = text.lower()
    return [CHAR_TO_IDX[c] for c in text if c in CHAR_TO_IDX]


def indices_to_text(indices: List[int]) -> str:
    """Переводит список индексов обратно в строку."""
    return "".join(IDX_TO_CHAR.get(i, "") for i in indices)


# ---------- Загрузка и нарезка аудио (из оригинального dataset.py) ----------

def load_audio(filepath: str, sample_rate: int) -> torch.Tensor:
    waveform, sr = torchaudio.load(filepath)
    if waveform.shape[0] > 1:
        waveform = waveform.mean(dim=0, keepdim=True)
    if sr != sample_rate:
        waveform = torchaudio.functional.resample(waveform, sr, sample_rate)
    return waveform.squeeze(0)


def get_chunk(waveform: torch.Tensor, chunk_len: int, random_crop: bool = True) -> torch.Tensor:
    data_len = len(waveform)
    if data_len >= chunk_len:
        start = random.randint(0, data_len - chunk_len) if random_crop else 0
        return waveform[start: start + chunk_len]
    else:
        # Зацикливаем короткие записи
        repeats = chunk_len // data_len + 1
        return waveform.repeat(repeats)[:chunk_len]


# ---------- Датасет ----------

class ASRDataset(Dataset):
    """
    Ожидает CSV с колонками:
        filepath    — путь к .flac/.wav файлу
        transcript  — текстовая расшифровка (для обучения)

    Пример строки CSV:
        train/speaker1/0001.flac,"привет как дела"

    При is_train=True применяет NoiseAugmentor если он передан.
    """

    def __init__(
        self,
        csv_path: str,
        sample_rate: int = 16000,
        chunk_seconds: float = 6.0,
        is_train: bool = True,
        base_dir: Optional[str] = None,
        augmentor: Optional[NoiseAugmentor] = None,
    ):
        self.df = pd.read_csv(csv_path)
        self.sample_rate = sample_rate
        self.chunk_len = int(sample_rate * chunk_seconds)
        self.is_train = is_train
        self.base_dir = base_dir
        self.augmentor = augmentor if is_train else None

        assert "filepath" in self.df.columns, "CSV должен содержать колонку 'filepath'"
        assert "transcript" in self.df.columns, "CSV должен содержать колонку 'transcript'"

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor, int]:
        row = self.df.iloc[idx]

        # Путь к файлу
        path = row["filepath"]
        if not os.path.isabs(path) and self.base_dir:
            path = os.path.normpath(os.path.join(self.base_dir, path))

        # Загрузка и нарезка аудио
        waveform = load_audio(path, self.sample_rate)
        waveform = get_chunk(waveform, self.chunk_len, random_crop=self.is_train)

        # Аугментация шумом (только при обучении)
        if self.augmentor is not None:
            waveform = self.augmentor(waveform)

        # Транскрипция → индексы символов
        text = str(row["transcript"]).strip().lower()
        label_indices = text_to_indices(text)
        labels = torch.tensor(label_indices, dtype=torch.long)

        return waveform, labels, len(labels)


def collate_fn(batch):
    """
    Собирает батч переменной длины для CTC Loss.
    Возвращает:
        waveforms:    (B, T) — аудио одинаковой длины (уже нарезано в датасете)
        labels:       (sum_label_lens,) — все метки подряд
        label_lens:   (B,) — длины меток каждого примера
    """
    waveforms, labels_list, label_lens = zip(*batch)

    waveforms = torch.stack(waveforms, dim=0)
    label_lens = torch.tensor(label_lens, dtype=torch.long)
    labels = torch.cat(labels_list, dim=0)

    return waveforms, labels, label_lens
