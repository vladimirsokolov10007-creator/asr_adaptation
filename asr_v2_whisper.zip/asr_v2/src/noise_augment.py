"""
Модуль шумовой аугментации для ASR.
Добавляет фоновый шум и реверберацию к аудио на лету во время обучения.

Исправления по сравнению с оригиналом:
  - Списки файлов кэшируются при первом обращении (rglob не вызывается на каждый пример)
"""

import os
import random
import torch
import torchaudio
import torchaudio.functional as F
from pathlib import Path
from typing import List, Optional


def _load_random_noise(noise_dir: str, target_len: int, sample_rate: int,
                        _cache: dict = {}) -> Optional[torch.Tensor]:
    """Загружает случайный шумовой файл из директории, обрезает/зацикливает до нужной длины.
    Список файлов кэшируется — без кэша rglob обходит всю директорию на каждый пример."""
    if noise_dir not in _cache:
        _cache[noise_dir] = (
            list(Path(noise_dir).rglob("*.wav")) +
            list(Path(noise_dir).rglob("*.flac"))
        )
    files = _cache[noise_dir]
    if not files:
        return None

    path = random.choice(files)
    noise, sr = torchaudio.load(str(path))
    if noise.shape[0] > 1:
        noise = noise.mean(dim=0, keepdim=True)
    noise = noise.squeeze(0)

    if sr != sample_rate:
        noise = F.resample(noise, sr, sample_rate)

    if len(noise) < target_len:
        repeats = target_len // len(noise) + 1
        noise = noise.repeat(repeats)
    start = random.randint(0, len(noise) - target_len)
    return noise[start: start + target_len]


def _load_random_rir(rir_dir: str, sample_rate: int,
                      _cache: dict = {}) -> Optional[torch.Tensor]:
    """Загружает случайный импульсный отклик (Room Impulse Response).
    Список файлов кэшируется аналогично _load_random_noise."""
    if rir_dir not in _cache:
        _cache[rir_dir] = (
            list(Path(rir_dir).rglob("*.wav")) +
            list(Path(rir_dir).rglob("*.flac"))
        )
    files = _cache[rir_dir]
    if not files:
        return None

    path = random.choice(files)
    rir, sr = torchaudio.load(str(path))
    if rir.shape[0] > 1:
        rir = rir.mean(dim=0, keepdim=True)
    rir = rir.squeeze(0)

    if sr != sample_rate:
        rir = F.resample(rir, sr, sample_rate)
    return rir


def mix_with_noise(waveform: torch.Tensor, noise: torch.Tensor, snr_db: float) -> torch.Tensor:
    """Смешивает речь с шумом при заданном SNR (в децибелах)."""
    signal_power = waveform.pow(2).mean().clamp(min=1e-9)
    noise_power = noise.pow(2).mean().clamp(min=1e-9)
    target_noise_power = signal_power / (10 ** (snr_db / 10))
    scale = (target_noise_power / noise_power).sqrt()
    return waveform + scale * noise


def apply_reverb(waveform: torch.Tensor, rir: torch.Tensor) -> torch.Tensor:
    """Применяет реверберацию через свёртку с импульсным откликом."""
    rir = rir / (rir.abs().max().clamp(min=1e-9))
    sig_len = waveform.shape[-1]
    rir_len = rir.shape[-1]
    fft_len = sig_len + rir_len - 1

    wf = torch.fft.rfft(waveform.float(), n=fft_len)
    ri = torch.fft.rfft(rir.float(), n=fft_len)
    out = torch.fft.irfft(wf * ri, n=fft_len)

    out = out[:sig_len]
    peak = out.abs().max().clamp(min=1e-9)
    if peak > 1.0:
        out = out / peak
    return out


class NoiseAugmentor:
    """
    Применяет случайные искажения к аудио во время обучения.

    Параметры:
        noise_dir:   директория с шумовыми файлами (MUSAN, DEMAND и т.п.)
        rir_dir:     директория с импульсными откликами (OpenSLR RIRs и т.п.)
        sample_rate: частота дискретизации
        snr_range:   диапазон SNR в дБ — (min, max)
        noise_prob:  вероятность добавить фоновый шум
        reverb_prob: вероятность добавить реверберацию
        speed_prob:  вероятность изменить скорость (±10%)
    """

    def __init__(
        self,
        noise_dir: Optional[str] = None,
        rir_dir: Optional[str] = None,
        sample_rate: int = 16000,
        snr_range: tuple = (0.0, 20.0),
        noise_prob: float = 0.7,
        reverb_prob: float = 0.5,
        speed_prob: float = 0.2,
    ):
        self.noise_dir = noise_dir
        self.rir_dir = rir_dir
        self.sample_rate = sample_rate
        self.snr_range = snr_range
        self.noise_prob = noise_prob
        self.reverb_prob = reverb_prob
        self.speed_prob = speed_prob

    def __call__(self, waveform: torch.Tensor) -> torch.Tensor:
        # 1. Реверберация
        if self.rir_dir and random.random() < self.reverb_prob:
            rir = _load_random_rir(self.rir_dir, self.sample_rate)
            if rir is not None:
                waveform = apply_reverb(waveform, rir)

        # 2. Фоновый шум
        if self.noise_dir and random.random() < self.noise_prob:
            noise = _load_random_noise(self.noise_dir, len(waveform), self.sample_rate)
            if noise is not None:
                snr = random.uniform(*self.snr_range)
                waveform = mix_with_noise(waveform, noise, snr)

        # 3. Изменение скорости (±10%)
        if random.random() < self.speed_prob:
            factor = random.uniform(0.9, 1.1)
            effects = [["speed", str(factor)], ["rate", str(self.sample_rate)]]
            waveform, _ = torchaudio.sox_effects.apply_effects_tensor(
                waveform.unsqueeze(0), self.sample_rate, effects, channels_first=True
            )
            waveform = waveform.squeeze(0)

        return waveform
