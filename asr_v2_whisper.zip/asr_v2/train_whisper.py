"""
Fine-tuning Whisper для распознавания русской (или любой другой) речи.

Архитектура:
    OpenAI Whisper (small / medium / large-v3)  →  Seq2SeqTrainer  →  WER

Почему Whisper, а не ECAPA-CTC с нуля:
  - Whisper предобучен на 680 000 часах речи включая русский
  - Fine-tuning занимает часы, а не недели
  - WER < 10% на чистой речи достижим на small-модели
  - Не нужна языковая модель — декодер Whisper сам является языковой моделью

Запуск:
    python train_whisper.py --config configs/whisper.json

Минимальный конфиг (configs/whisper.json):
    {
      "model_name": "openai/whisper-small",
      "language": "russian",
      "train_csv": "./data/train_asr.csv",
      "val_csv":   "./data/val_asr.csv",
      "output_dir": "./experiments/whisper-small-ru"
    }
"""

import argparse
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Union

import torch
import numpy as np
from transformers import (
    WhisperForConditionalGeneration,
    WhisperProcessor,
    Seq2SeqTrainer,
    Seq2SeqTrainingArguments,
)

from src.whisper_dataset import WhisperASRDataset, WhisperDataCollator
from src.noise_augment import NoiseAugmentor
from src.metrics import compute_wer, compute_cer, wer_report


# ---------------------------------------------------------------------------
# Compute metrics callback для Seq2SeqTrainer
# ---------------------------------------------------------------------------

def make_compute_metrics(processor: WhisperProcessor):
    """
    Фабрика: возвращает функцию compute_metrics с захваченным processor.
    Seq2SeqTrainer вызывает её после каждой эпохи валидации.
    """
    def compute_metrics(eval_pred):
        pred_ids, label_ids = eval_pred

        # Заменяем -100 (паддинг) на pad_token_id для декодирования
        label_ids[label_ids == -100] = processor.tokenizer.pad_token_id

        # Декодируем предсказания и эталоны
        predictions = processor.batch_decode(pred_ids, skip_special_tokens=True)
        references = processor.batch_decode(label_ids, skip_special_tokens=True)

        wer = compute_wer(predictions, references)
        cer = compute_cer(predictions, references)

        # Логируем несколько примеров (видно в консоли, не в метриках)
        print("\n" + wer_report(predictions, references, n_examples=3))

        return {
            "wer": round(wer, 4),
            "cer": round(cer, 4),
        }

    return compute_metrics


# ---------------------------------------------------------------------------
# Главный скрипт
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Fine-tuning Whisper для ASR")
    parser.add_argument("--config", required=True, help="Путь к JSON-конфигу")
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = json.load(f)

    # --- Модель и процессор ---
    model_name = cfg.get("model_name", "openai/whisper-small")
    language = cfg.get("language", "russian")
    task = cfg.get("task", "transcribe")

    print(f"[INFO] Загружаем модель: {model_name}")
    processor = WhisperProcessor.from_pretrained(model_name, language=language, task=task)
    model = WhisperForConditionalGeneration.from_pretrained(model_name)

    # Принудительно задаём язык и задачу — без этого Whisper может переключиться
    model.config.forced_decoder_ids = processor.get_decoder_prompt_ids(
        language=language, task=task
    )
    model.config.suppress_tokens = []

    # Gradient checkpointing — экономит VRAM при обучении (незначительно медленнее)
    if cfg.get("gradient_checkpointing", True):
        model.config.use_cache = False
        model.gradient_checkpointing_enable()

    # --- Аугментация ---
    augmentor = None
    if cfg.get("noise_dir") or cfg.get("rir_dir"):
        augmentor = NoiseAugmentor(
            noise_dir=cfg.get("noise_dir"),
            rir_dir=cfg.get("rir_dir"),
            sample_rate=16000,
            snr_range=(cfg.get("snr_min", 5), cfg.get("snr_max", 20)),
            noise_prob=cfg.get("noise_prob", 0.5),
            reverb_prob=cfg.get("reverb_prob", 0.3),
            speed_prob=cfg.get("speed_prob", 0.1),
        )
        print("[INFO] Шумовая аугментация включена")
    else:
        print("[INFO] Аугментация отключена (noise_dir и rir_dir не заданы)")

    # --- Датасеты ---
    base_dir = cfg.get("data_base_dir", ".")

    train_ds = WhisperASRDataset(
        csv_path=cfg["train_csv"],
        processor=processor,
        is_train=True,
        base_dir=base_dir,
        augmentor=augmentor,
        language=language,
        max_chars=cfg.get("max_chars", 400),
    )
    val_ds = WhisperASRDataset(
        csv_path=cfg["val_csv"],
        processor=processor,
        is_train=False,
        base_dir=base_dir,
        augmentor=None,
        language=language,
        max_chars=cfg.get("max_chars", 400),
    )

    collator = WhisperDataCollator(processor)

    # --- Аргументы тренера ---
    output_dir = cfg.get("output_dir", "./experiments/whisper-finetuned")
    os.makedirs(output_dir, exist_ok=True)

    training_args = Seq2SeqTrainingArguments(
        output_dir=output_dir,

        # Размер батча
        per_device_train_batch_size=cfg.get("batch_size", 8),
        per_device_eval_batch_size=cfg.get("eval_batch_size", 8),

        # Gradient accumulation: эффективный batch = batch_size × accumulation_steps
        # На GPU с 8GB VRAM: batch=4, accumulation=4 → effective batch=16
        gradient_accumulation_steps=cfg.get("gradient_accumulation_steps", 2),

        # Learning rate с warmup
        learning_rate=cfg.get("lr", 1e-5),
        warmup_steps=cfg.get("warmup_steps", 500),
        lr_scheduler_type="cosine",

        # Длительность обучения
        max_steps=cfg.get("max_steps", -1),
        num_train_epochs=cfg.get("epochs", 10),

        # Mixed precision
        fp16=cfg.get("fp16", torch.cuda.is_available()),
        bf16=cfg.get("bf16", False),

        # Gradient checkpointing
        gradient_checkpointing=cfg.get("gradient_checkpointing", True),

        # Evaluation
        evaluation_strategy="steps",
        eval_steps=cfg.get("eval_steps", 500),
        save_strategy="steps",
        save_steps=cfg.get("save_steps", 500),
        load_best_model_at_end=True,
        metric_for_best_model="wer",
        greater_is_better=False,

        # Generation settings для валидации
        predict_with_generate=True,
        generation_max_length=cfg.get("generation_max_length", 225),

        # Логирование
        logging_steps=cfg.get("logging_steps", 25),
        report_to=cfg.get("report_to", "none"),  # "tensorboard" или "wandb" если нужно

        # Сохранение
        save_total_limit=cfg.get("save_total_limit", 3),

        # DataLoader
        dataloader_num_workers=cfg.get("num_workers", 4),
        remove_unused_columns=False,  # ВАЖНО: иначе Trainer удалит наши поля
    )

    # --- Тренер ---
    trainer = Seq2SeqTrainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        data_collator=collator,
        compute_metrics=make_compute_metrics(processor),
        tokenizer=processor.feature_extractor,
    )

    # --- Обучение ---
    print(f"\n[INFO] Начинаем обучение. Output: {output_dir}")
    print(f"[INFO] Train: {len(train_ds)} | Val: {len(val_ds)}")
    print(f"[INFO] Модель: {model_name} | Язык: {language}\n")

    # Возобновление с чекпоинта если есть
    checkpoint = None
    if cfg.get("resume_from_checkpoint"):
        checkpoint = cfg["resume_from_checkpoint"]
        print(f"[INFO] Возобновление с чекпоинта: {checkpoint}")

    trainer.train(resume_from_checkpoint=checkpoint)

    # --- Сохранение финальной модели ---
    final_dir = os.path.join(output_dir, "final")
    trainer.save_model(final_dir)
    processor.save_pretrained(final_dir)
    print(f"\n[DONE] Модель сохранена: {final_dir}")

    # --- Финальная оценка ---
    print("\n[INFO] Финальная оценка на валидации...")
    metrics = trainer.evaluate()
    print(f"Финальный WER: {metrics.get('eval_wer', '?'):.4f}")
    print(f"Финальный CER: {metrics.get('eval_cer', '?'):.4f}")


if __name__ == "__main__":
    main()
