@echo off
REM =============================================================
REM  Шаг 2 для Windows: создать venv и установить зависимости
REM  Запуск: дважды кликни или в PowerShell: .\step2_setup_env_windows.bat
REM =============================================================

echo ==============================
echo  Шаг 2: Настройка окружения
echo ==============================

REM Проверяем Python
python --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [ERR] Python не найден.
    echo       Скачай с https://www.python.org/downloads/
    echo       При установке поставь галочку "Add Python to PATH"
    pause
    exit /b 1
)

echo [INFO] Python найден:
python --version

REM Создаём venv
IF EXIST venv (
    echo [SKIP] Окружение уже существует
) ELSE (
    echo [INFO] Создаём виртуальное окружение...
    python -m venv venv
)

REM Активируем
call venv\Scripts\activate.bat
echo [INFO] Окружение активировано

REM pip
pip install --upgrade pip -q

REM PyTorch с CUDA 12.4
echo [INFO] Устанавливаем PyTorch + CUDA 12.4...
pip install torch==2.7.0 torchaudio==2.7.0 --extra-index-url https://download.pytorch.org/whl/cu124 -q

REM Остальные зависимости
echo [INFO] Устанавливаем зависимости...
pip install numpy pandas==2.2.2 soundfile==0.12.1 tqdm==4.66.6 onnx onnxruntime-gpu openai-whisper pyctcdecode jiwer datasets huggingface_hub faiss-cpu -q

REM Проверка
echo.
echo [ПРОВЕРКА] Видит ли Python GPU...
python -c "import torch; print('CUDA доступна:', torch.cuda.is_available()); print('GPU:', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'не найден')"

echo.
echo [ГОТОВО] Окружение настроено.
echo.
echo Для активации в следующий раз:
echo     venv\Scripts\activate
echo.
pause
