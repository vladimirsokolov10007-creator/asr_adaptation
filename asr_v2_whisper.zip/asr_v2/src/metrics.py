"""
Подсчёт WER (Word Error Rate) и CER (Character Error Rate).

WER — стандартная метрика для ASR:
    WER = (S + D + I) / N
    S = замены, D = удаления, I = вставки, N = число слов в эталоне

CER — то же, но на символьном уровне (полезно для языков без пробелов,
      а также для диагностики на ранних эпохах когда слова ещё не складываются).

Оба метода нормализуют текст перед подсчётом через text_normalize.normalize_for_wer().
"""

from typing import List, Tuple
from .text_normalize import normalize_for_wer


def _levenshtein(a: list, b: list) -> Tuple[int, int, int]:
    """
    Расстояние Левенштейна между двумя списками токенов.
    Возвращает (substitutions + deletions + insertions, ref_len, edit_distance).
    """
    m, n = len(a), len(b)
    # dp[j] = edit distance для a[:i] vs b[:j]
    dp = list(range(n + 1))
    for i in range(1, m + 1):
        prev, dp[0] = dp[0], i
        for j in range(1, n + 1):
            temp = dp[j]
            dp[j] = prev if a[i-1] == b[j-1] else 1 + min(prev, dp[j], dp[j-1])
            prev = temp
    return dp[n], m


def compute_wer(predictions: List[str], references: List[str]) -> float:
    """
    Word Error Rate для списка пар (предсказание, эталон).
    Перед подсчётом оба текста нормализуются.

    Возвращает значение в диапазоне [0, ∞):
      0.0  — идеальное распознавание
      1.0  — ошибок столько же, сколько слов в эталоне
      >1.0 — вставок больше, чем слов (бывает у плохих моделей)
    """
    total_errors, total_words = 0, 0
    for pred, ref in zip(predictions, references):
        pred_words = normalize_for_wer(pred).split()
        ref_words = normalize_for_wer(ref).split()
        errors, ref_len = _levenshtein(pred_words, ref_words)
        total_errors += errors
        total_words += max(ref_len, 1)
    return total_errors / max(total_words, 1)


def compute_cer(predictions: List[str], references: List[str]) -> float:
    """
    Character Error Rate — то же что WER, но на уровне символов.
    Полезно для диагностики: если CER низкий а WER высокий — модель
    путает границы слов, но звуки слышит правильно.
    """
    total_errors, total_chars = 0, 0
    for pred, ref in zip(predictions, references):
        pred_chars = list(normalize_for_wer(pred).replace(" ", ""))
        ref_chars = list(normalize_for_wer(ref).replace(" ", ""))
        errors, ref_len = _levenshtein(pred_chars, ref_chars)
        total_errors += errors
        total_chars += max(ref_len, 1)
    return total_errors / max(total_chars, 1)


def wer_report(predictions: List[str], references: List[str], n_examples: int = 5) -> str:
    """
    Форматированный отчёт: WER + CER + примеры ошибок.
    """
    wer = compute_wer(predictions, references)
    cer = compute_cer(predictions, references)

    lines = [
        f"WER: {wer:.4f} ({wer*100:.1f}%)",
        f"CER: {cer:.4f} ({cer*100:.1f}%)",
        "",
        f"Примеры ({min(n_examples, len(predictions))}):",
    ]
    for i, (pred, ref) in enumerate(zip(predictions[:n_examples], references[:n_examples])):
        lines.append(f"  эталон: {normalize_for_wer(ref)}")
        lines.append(f"  модель: {normalize_for_wer(pred)}")
        lines.append("")

    return "\n".join(lines)
