"""
Скрипт обучения ASR-модели с CTC Loss.
Структура максимально повторяет оригинальный train.py из бейзлайна,
но добавляет:
  - NoiseAugmentor (шум + реверб + смена скорости)
  - CTC Loss вместо CrossEntropy
  - WER (Word Error Rate) вместо Precision@K

Запуск:
    python train_asr.py --config configs/asr.json

Пример конфига (configs/asr.json):
{
  "exp_dir":            "./experiments/asr",
  "data_base_dir":      "./data",
  "train_csv":          "./data/train_asr.csv",
  "val_csv":            "./data/val_asr.csv",
  "noise_dir":          "./data/musan/noise",
  "rir_dir":            "./data/rir",
  "snr_min":            0,
  "snr_max":            20,
  "noise_prob":         0.7,
  "reverb_prob":        0.5,
  "speed_prob":         0.2,
  "sample_rate":        16000,
  "chunk_seconds":      6.0,
  "n_mels":             80,
  "n_fft":              400,
  "hop_length":         160,
  "channels":           512,
  "batch_size":         32,
  "num_workers":        4,
  "epochs":             30,
  "lr":                 0.0003,
  "weight_decay":       0.00001,
  "device":             "auto"
}
"""

import argparse
import json
import os
from time import perf_counter

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from src.asr_dataset import ASRDataset, collate_fn
from src.asr_model import ECAPAAsrModel, BLANK_IDX
from src.noise_augment import NoiseAugmentor


# ---------- WER (Word Error Rate) ----------

def _levenshtein(a: list, b: list) -> int:
    """Расстояние Левенштейна между двумя списками слов."""
    m, n = len(a), len(b)
    dp = list(range(n + 1))
    for i in range(1, m + 1):
        prev, dp[0] = dp[0], i
        for j in range(1, n + 1):
            temp = dp[j]
            dp[j] = prev if a[i-1] == b[j-1] else 1 + min(prev, dp[j], dp[j-1])
            prev = temp
    return dp[n]


def compute_wer(predictions: list, references: list) -> float:
    """
    Word Error Rate = (S + D + I) / N
    S — замены, D — удаления, I — вставки, N — число слов в эталоне.
    """
    total_errors, total_words = 0, 0
    for pred, ref in zip(predictions, references):
        pred_words = pred.strip().split()
        ref_words = ref.strip().split()
        total_errors += _levenshtein(pred_words, ref_words)
        total_words += max(len(ref_words), 1)
    return total_errors / max(total_words, 1)


# ---------- Одна эпоха обучения ----------

def train_one_epoch(model, loader, optimizer, ctc_loss, device, desc="train"):
    model.train()
    total_loss, n_batches = 0.0, 0

    pbar = tqdm(loader, desc=desc, dynamic_ncols=True, leave=False)
    for waveforms, labels, label_lens in pbar:
        waveforms = waveforms.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)
        label_lens = label_lens.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)

        log_probs, input_lengths = model(waveforms)
        input_lengths = input_lengths.to(device)

        loss = ctc_loss(log_probs, labels, input_lengths, label_lens)
        loss.backward()

        # Gradient clipping — важно для CTC
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)

        optimizer.step()

        total_loss += loss.item()
        n_batches += 1
        pbar.set_postfix(loss=f"{loss.item():.4f}", avg=f"{total_loss/n_batches:.4f}")

    return total_loss / max(n_batches, 1)


# ---------- Валидация с подсчётом WER ----------

@torch.no_grad()
def validate(model, loader, device, df_val):
    model.eval()
    all_preds = []

    for waveforms, _, _ in tqdm(loader, desc="val", dynamic_ncols=True, leave=False):
        waveforms = waveforms.to(device, non_blocking=True)
        preds = model.decode_greedy(waveforms)
        all_preds.extend(preds)

    references = df_val["transcript"].str.lower().tolist()
    wer = compute_wer(all_preds, references)
    return wer, all_preds[:3], references[:3]   # первые 3 примера для лога


# ---------- Главный скрипт ----------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Путь к JSON-конфигу")
    args = parser.parse_args()

    with open(args.config) as f:
        cfg = json.load(f)

    os.makedirs(cfg["exp_dir"], exist_ok=True)

    device = "cuda" if (cfg.get("device", "auto") == "auto" and torch.cuda.is_available()) \
             else cfg.get("device", "cpu")
    print(f"[INFO] Устройство: {device}")

    # Аугментатор — передаётся в датасет
    augmentor = NoiseAugmentor(
        noise_dir=cfg.get("noise_dir"),
        rir_dir=cfg.get("rir_dir"),
        sample_rate=cfg["sample_rate"],
        snr_range=(cfg.get("snr_min", 0), cfg.get("snr_max", 20)),
        noise_prob=cfg.get("noise_prob", 0.7),
        reverb_prob=cfg.get("reverb_prob", 0.5),
        speed_prob=cfg.get("speed_prob", 0.2),
    )

    train_ds = ASRDataset(
        csv_path=cfg["train_csv"],
        sample_rate=cfg["sample_rate"],
        chunk_seconds=cfg["chunk_seconds"],
        is_train=True,
        base_dir=cfg.get("data_base_dir"),
        augmentor=augmentor,
    )
    val_ds = ASRDataset(
        csv_path=cfg["val_csv"],
        sample_rate=cfg["sample_rate"],
        chunk_seconds=cfg["chunk_seconds"],
        is_train=False,
        base_dir=cfg.get("data_base_dir"),
        augmentor=None,          # на валидации — чистый звук
    )

    print(f"[INFO] Обучающих примеров: {len(train_ds)} | Валидационных: {len(val_ds)}")

    train_loader = DataLoader(
        train_ds, batch_size=cfg["batch_size"], shuffle=True,
        num_workers=cfg["num_workers"], pin_memory=True,
        drop_last=True, collate_fn=collate_fn,
    )
    val_loader = DataLoader(
        val_ds, batch_size=cfg["batch_size"], shuffle=False,
        num_workers=cfg["num_workers"], pin_memory=True,
        drop_last=False, collate_fn=collate_fn,
    )

    model = ECAPAAsrModel(
        sample_rate=cfg["sample_rate"],
        n_fft=cfg["n_fft"],
        hop_length=cfg["hop_length"],
        n_mels=cfg["n_mels"],
        channels=cfg.get("channels", 512),
    ).to(device)

    # CTC Loss: blank_idx=0, zero_infinity=True чтобы не падать на коротких примерах
    ctc_loss = nn.CTCLoss(blank=BLANK_IDX, reduction="mean", zero_infinity=True)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.get("lr", 3e-4),
        weight_decay=cfg.get("weight_decay", 1e-5),
    )
    # Расписание LR: прогрев 5% эпох, затем косинусный спад
    epochs = int(cfg["epochs"])
    warmup_steps = max(1, int(0.05 * epochs * len(train_loader)))
    scheduler = torch.optim.lr_scheduler.OneCycleLR(
        optimizer, max_lr=cfg.get("lr", 3e-4),
        steps_per_epoch=len(train_loader), epochs=epochs,
    )

    best_wer = float("inf")
    save_path = os.path.join(cfg["exp_dir"], "asr_model.pt")

    for epoch in range(1, epochs + 1):
        t0 = perf_counter()

        train_loss = train_one_epoch(
            model, train_loader, optimizer, ctc_loss, device,
            desc=f"train {epoch:03d}/{epochs:03d}",
        )
        scheduler.step()

        wer, pred_examples, ref_examples = validate(model, val_loader, device, val_ds.df)
        dt = perf_counter() - t0

        if wer < best_wer:
            best_wer = wer
            torch.save(model.state_dict(), save_path)
            saved_mark = " ← сохранено"
        else:
            saved_mark = ""

        print(
            f"Epoch {epoch:03d}/{epochs:03d} | "
            f"loss {train_loss:.4f} | WER {wer:.4f} | best WER {best_wer:.4f} | "
            f"время {dt:.1f}с{saved_mark}"
        )

        # Показываем примеры расшифровки
        if epoch % 5 == 0 or epoch == 1:
            print("[Примеры расшифровки]")
            for p, r in zip(pred_examples, ref_examples):
                print(f"  эталон: {r}")
                print(f"  модель: {p}")
                print()

    print(f"\n[DONE] Лучший WER: {best_wer:.4f} | модель сохранена: {save_path}")


if __name__ == "__main__":
    main()
